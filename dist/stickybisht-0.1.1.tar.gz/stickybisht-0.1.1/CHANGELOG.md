## [0.1.1] - 2024-11-17
### Added
- New feature: Double click toggle minimise and default size

### Fixed
- Border scrollable thickness
