from .stickybisht_notes import StickyNote

__version__ = "0.1.0"
__all__ = ["StickyNote"]
